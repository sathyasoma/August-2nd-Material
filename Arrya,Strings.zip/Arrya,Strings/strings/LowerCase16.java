package com.strings;
//Write a program to convert all the characters in a string to Lowercase

public class LowerCase16 {
	public static void main(String[] args)
	{
		String str = "Sathya Keerthi Computer Education";
		String lwr_str = str.toLowerCase();
		System.out.println("Given String : " + str);
		System.out.println("String in Lowercase : " + lwr_str);
	}
}
