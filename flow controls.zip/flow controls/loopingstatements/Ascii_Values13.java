package com.loopingstatements;
//Write a program to print the ASCII values
public class Ascii_Values13 {
	public static void main(String[] args)
	{
		for(int s=1;s<=255;s++)
		{
			System.out.println((char)s);	
		}
 
	}
}
